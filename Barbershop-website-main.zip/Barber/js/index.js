const d = new Date();
document.getElementById('demo').innerHTML = 'Copyright ' + d.getFullYear();