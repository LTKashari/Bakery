# Barbershop-website
A simple barbeshop wesbite for beginners using HTML, CSS and JavaScript
